// Term--Winter 2024

#include "A1.hpp"

int main( int argc, char **argv )
{
	CS488Window::launch( argc, argv, new A1(), 1024, 768, "W24 Assignment 1" );
	return 0;
}
